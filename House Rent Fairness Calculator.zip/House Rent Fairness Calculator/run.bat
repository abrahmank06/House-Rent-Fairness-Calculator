@echo off
REM House Rent Fairness Calculator - Windows Startup Script

echo.
echo ====================================
echo   House Rent Fairness Calculator
echo ====================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Error: Python is not installed or not in PATH
    echo Please install Python from https://www.python.org/
    pause
    exit /b 1
)

REM Check if virtual environment exists
if not exist "venv" (
    echo Creating virtual environment...
    python -m venv venv
    if %errorlevel% neq 0 (
        echo Error: Failed to create virtual environment
        pause
        exit /b 1
    )
)

REM Activate virtual environment
echo Activating virtual environment...
call venv\Scripts\activate.bat

REM Install dependencies
echo Installing dependencies...
pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo Error: Failed to install dependencies
    pause
    exit /b 1
)

REM Check if model file exists
if not exist "house_price_model.pkl" (
    echo.
    echo WARNING: house_price_model.pkl not found!
    echo.
    echo Please ensure the model file is in the same directory as app.py
    echo You can generate it from the Jupyter notebook by running:
    echo     import joblib
    echo     joblib.dump(model, 'house_price_model.pkl')
    echo.
    pause
)

REM Run the Flask app
echo.
echo ✅ Starting Flask server...
echo.
echo Open your browser and go to: http://localhost:5000
echo.
echo Press Ctrl+C to stop the server
echo.
python app.py

pause
