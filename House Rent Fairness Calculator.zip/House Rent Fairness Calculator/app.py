from flask import Flask, render_template, request, jsonify
import joblib
import pandas as pd
import numpy as np
import os

app = Flask(__name__)

# Load the trained model
MODEL_PATH = 'house_price_model.pkl'

# Global variables to store the model and available locations
model = None
available_locations = []

def load_model():
    """Load the model and extract available locations from the trained encoder"""
    global model, available_locations
    
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Model file '{MODEL_PATH}' not found. Please ensure the .pkl file is in the same directory.")
    
    model = joblib.load(MODEL_PATH)
    
    # Extract available locations from the OneHotEncoder
    try:
        encoder = model.named_steps['preprocessor'].named_transformers_['cat']
        location_index = list(model.named_steps['preprocessor'].transformers_[1][2]).index('location')
        available_locations = encoder.categories_[location_index].tolist()
        # Remove "Other" from the list
        if "Other" in available_locations:
            available_locations.remove("Other")
    except Exception as e:
        print(f"Warning: Could not extract locations: {e}")
        available_locations = []

@app.route('/')
def home():
    """Render the main page"""
    return render_template('index_minimalist.html', locations=available_locations)

@app.route('/matrix')
def matrix():
    """Render the matrix-themed page"""
    return render_template('index_matrix.html', locations=available_locations)

@app.route('/minimalist')
def minimalist():
    """Render the minimalist-themed page"""
    return render_template('index_minimalist.html', locations=available_locations)

@app.route('/predict', methods=['POST'])
def predict():
    """
    Predict the house price based on input features.
    Expected JSON input:
    {
        "bedrooms": int,
        "baths": int,
        "size": int,
        "location": str,
        "is_furnished": bool
    }
    """
    try:
        data = request.get_json()
        
        # Validate input
        if not data:
            return jsonify({'error': 'No input data provided'}), 400
        
        required_fields = ['bedrooms', 'baths', 'size', 'location', 'is_furnished']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing field: {field}'}), 400
        
        # Extract and validate inputs
        try:
            bedrooms = int(data['bedrooms'])
            baths = int(data['baths'])
            size = int(data['size'])
        except (ValueError, TypeError):
            return jsonify({'error': 'Bedrooms, Baths, and Size must be valid numbers'}), 400
        
        # Validate positive numbers
        if bedrooms < 0 or baths < 0 or size < 0:
            return jsonify({'error': 'Bedrooms, Baths, and Size must be positive numbers'}), 400
        
        location = str(data['location']).strip()
        is_furnished = bool(data['is_furnished'])
        
        if not location:
            return jsonify({'error': 'Location cannot be empty'}), 400
        
        # Create input DataFrame
        input_data = pd.DataFrame({
            'bedrooms': [bedrooms],
            'baths': [baths],
            'size': [size],
            'location': [location],
            'Is_furnished': [is_furnished]
        })
        
        # Apply log1p transformation (same as training)
        input_data['bedrooms'] = np.log1p(input_data['bedrooms'])
        input_data['baths'] = np.log1p(input_data['baths'])
        input_data['size'] = np.log1p(input_data['size'])
        
        # Make prediction
        predicted_log_price = model.predict(input_data)[0]
        
        # Reverse log transformation (expm1)
        predicted_real_price = np.expm1(predicted_log_price)
        
        return jsonify({
            'success': True,
            'predicted_price': round(predicted_real_price, 2),
            'input': {
                'bedrooms': bedrooms,
                'baths': baths,
                'size': size,
                'location': location,
                'is_furnished': is_furnished
            }
        }), 200
    
    except Exception as e:
        return jsonify({'error': f'Prediction error: {str(e)}'}), 500

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({'status': 'Model server is running', 'model_loaded': model is not None}), 200

if __name__ == '__main__':
    try:
        load_model()
        print("✅ Model loaded successfully!")
        app.run(debug=True, host='0.0.0.0', port=5000)
    except FileNotFoundError as e:
        print(f"❌ {e}")
        print("Please ensure 'house_price_model.pkl' is in the same directory as app.py")
    except Exception as e:
        print(f"❌ Error loading model: {e}")
