# House Rent Fairness Calculator - Web Application

A modern, clean web application for predicting residential rent prices using a machine learning model (Ridge Regression with scikit-learn).

## 📁 Project Structure

```
├── app.py                          # Flask backend server
├── templates/
│   └── index.html                 # Frontend HTML with Tailwind CSS & JavaScript
├── requirements.txt               # Python dependencies
├── house_price_model.pkl          # Trained ML model (generate from notebook)
└── README.md                      # This file
```

## 🚀 Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Ensure Model File Exists

Make sure `house_price_model.pkl` is in the same directory as `app.py`. 
This file should be generated from your Jupyter notebook using:

```python
import joblib
joblib.dump(model, 'house_price_model.pkl')
```

### 3. Run the Application

```bash
python app.py
```

You should see:
```
✅ Model loaded successfully!
 * Running on http://0.0.0.0:5000
```

### 4. Open in Browser

Navigate to: **http://localhost:5000**

## 🎨 Features

### Frontend
- ✨ **Modern UI**: Built with Tailwind CSS for a professional, responsive design
- 📱 **Responsive**: Works seamlessly on desktop, tablet, and mobile
- ⚡ **Real-time Validation**: Client-side form validation before submission
- 🎯 **Intuitive Form**: Easy-to-use input fields for all property features:
  - Number of Bedrooms (numerical input)
  - Number of Bathrooms (numerical input)
  - Size in Square Feet (numerical input)
  - Location (text input)
  - Furnished Status (Yes/No radio buttons)
- 💬 **Dynamic Results**: Results display without page reload using fetch API
- 🔄 **Loading State**: Visual feedback during prediction
- ⚠️ **Error Handling**: Clear error messages for invalid inputs or server errors

### Backend
- 🔐 **Model Loading**: Safely loads the trained scikit-learn Pipeline
- 📊 **Data Transformation**: Applies the same log1p transformations as during training
- ✅ **Input Validation**: Comprehensive validation for all required fields
- 🔍 **Prediction**: Uses Ridge Regression to predict fair rental prices
- 🎁 **API Response**: Returns predicted price with input summary
- 💪 **Error Handling**: Graceful error handling with informative messages
- 🏥 **Health Check**: `/health` endpoint to verify model server status

## 📡 API Endpoints

### POST /predict
**Request:**
```json
{
  "bedrooms": 4,
  "baths": 2,
  "size": 3000,
  "location": "F-7",
  "is_furnished": false
}
```

**Response (Success):**
```json
{
  "success": true,
  "predicted_price": 75000.00,
  "input": {
    "bedrooms": 4,
    "baths": 2,
    "size": 3000,
    "location": "F-7",
    "is_furnished": false
  }
}
```

**Response (Error):**
```json
{
  "error": "Bedrooms, Baths, and Size must be positive numbers"
}
```

### GET /health
Check if the model server is running.

**Response:**
```json
{
  "status": "Model server is running",
  "model_loaded": true
}
```

## 🔧 Configuration

- **Port**: 5000 (default)
- **Host**: 0.0.0.0 (accessible from any network interface)
- **Debug Mode**: Enabled (auto-reload on code changes)

To change settings, edit `app.py`:
```python
app.run(debug=True, host='0.0.0.0', port=5000)
```

## 🛠️ Troubleshooting

### Model file not found
**Error**: `FileNotFoundError: Model file 'house_price_model.pkl' not found`
- Ensure `house_price_model.pkl` is saved in the same directory as `app.py`
- Regenerate the model from your Jupyter notebook if needed

### Port already in use
**Error**: `OSError: [Errno 10048] Only one usage of each socket address`
- Change the port in `app.py`:
  ```python
  app.run(debug=True, host='0.0.0.0', port=5001)  # Use port 5001 instead
  ```

### Module not found errors
**Error**: `ModuleNotFoundError: No module named 'flask'`
- Ensure all dependencies are installed:
  ```bash
  pip install -r requirements.txt
  ```

### CORS Issues (when accessing from different domain)
If you're accessing the app from a different domain, add CORS support:
```python
from flask_cors import CORS
CORS(app)
```
Then add `flask-cors` to `requirements.txt`.

## 📝 How the Model Works

The trained model uses:
- **Algorithm**: Ridge Regression with regularization
- **Features**: 
  - Bedrooms, Bathrooms, Size (scaled with StandardScaler)
  - Location, Furnished Status (one-hot encoded)
- **Transformations**:
  - Input features: log1p transformation applied during preprocessing
  - Target variable: log-transformed during training
  - Output: Reverse log-transformation (expm1) to get actual price

## 🔐 Input Validation

All inputs are validated on both client (JavaScript) and server (Python):
- **Bedrooms, Baths, Size**: Must be non-negative integers
- **Location**: Cannot be empty (any text is accepted)
- **Furnished**: Boolean (Yes/No)

## 📦 Dependencies

- **Flask**: Web framework for Python
- **pandas**: Data manipulation
- **numpy**: Numerical computations
- **scikit-learn**: Machine learning models and preprocessing
- **joblib**: Model serialization/deserialization
- **Tailwind CSS**: Modern CSS framework (loaded via CDN)

## 🚢 Deployment

To deploy this application:

1. **Heroku**:
   ```bash
   heroku create your-app-name
   git push heroku main
   ```

2. **Docker**:
   Create a `Dockerfile` and deploy to any cloud provider

3. **Traditional Hosting**:
   Use Gunicorn as a production server:
   ```bash
   pip install gunicorn
   gunicorn app:app
   ```

## 📄 License

This project is for educational purposes.

## 👨‍💻 Author

Created as part of a Machine Learning course project.

---

**Questions?** Check the model training notebook for more details about the data, training process, and model performance.
