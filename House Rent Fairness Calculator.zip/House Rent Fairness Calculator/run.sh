#!/bin/bash

# House Rent Fairness Calculator - Linux/Mac Startup Script

echo ""
echo "===================================="
echo "  House Rent Fairness Calculator"
echo "===================================="
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is not installed"
    echo "Please install Python 3 first"
    exit 1
fi

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
    if [ $? -ne 0 ]; then
        echo "Error: Failed to create virtual environment"
        exit 1
    fi
fi

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Install dependencies
echo "Installing dependencies..."
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "Error: Failed to install dependencies"
    exit 1
fi

# Check if model file exists
if [ ! -f "house_price_model.pkl" ]; then
    echo ""
    echo "WARNING: house_price_model.pkl not found!"
    echo ""
    echo "Please ensure the model file is in the same directory as app.py"
    echo "You can generate it from the Jupyter notebook by running:"
    echo "    import joblib"
    echo "    joblib.dump(model, 'house_price_model.pkl')"
    echo ""
    read -p "Press Enter to continue..."
fi

# Run the Flask app
echo ""
echo "✅ Starting Flask server..."
echo ""
echo "Open your browser and go to: http://localhost:5000"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""
python app.py
