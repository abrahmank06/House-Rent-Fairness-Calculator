# 🚀 Quick Setup Guide

## What I've Created For You

I've built a complete web application stack for your ML model:

```
House Rent Fairness Calculator/
├── app.py                    ← Flask backend server
├── templates/
│   └── index.html           ← Modern responsive frontend
├── requirements.txt         ← Python dependencies
├── README.md               ← Full documentation
├── run.bat                 ← Windows startup script
├── run.sh                  ← Linux/Mac startup script
├── .gitignore              ← Git configuration
└── house_price_model.pkl   ← Your trained model (you already have this!)
```

## ⚡ Quickest Way to Start (Windows)

1. **Double-click `run.bat`** in your project folder
2. Wait for it to set up everything
3. Open browser → http://localhost:5000
4. Done! 🎉

## 📋 Manual Setup (All Platforms)

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Verify Model File
Make sure `house_price_model.pkl` exists in your project folder (you already created this in the notebook).

### Step 3: Run the App
```bash
python app.py
```

### Step 4: Open Browser
Navigate to: **http://localhost:5000**

---

## 🎨 What You Get

### Backend Features (Flask)
✅ Loads your trained Ridge Regression model  
✅ Applies log1p transformations (same as training)  
✅ Validates all user inputs  
✅ Returns predictions with expm1 reverse transformation  
✅ Handles errors gracefully  
✅ JSON API for easy integration  

### Frontend Features (HTML/CSS/JS)
✅ Beautiful gradient header with Tailwind CSS  
✅ Responsive form layout (works on mobile/tablet/desktop)  
✅ Real-time validation  
✅ Loading animation during prediction  
✅ Dynamic result display (no page reload)  
✅ Input summary showing what was predicted  
✅ Clear error messages  

---

## 📝 File Descriptions

| File | Purpose |
|------|---------|
| `app.py` | Flask server that loads model and serves predictions |
| `templates/index.html` | Web interface with form and results display |
| `requirements.txt` | Python packages needed (Flask, pandas, scikit-learn, etc.) |
| `run.bat` | Windows: One-click startup with virtual environment setup |
| `run.sh` | Linux/Mac: Shell script for startup |
| `README.md` | Complete documentation and API reference |
| `.gitignore` | Git configuration (ignore cache/venv) |

---

## 🔍 How It Works

1. **User fills form** → Bedrooms, Baths, Size, Location, Furnished status
2. **Click "Estimate Price"** → JavaScript sends JSON to `/predict` endpoint
3. **Backend processes** → Applies log transformations, feeds to model
4. **Model predicts** → Ridge Regression gives log-price prediction
5. **Backend reverses** → Converts from log-price back to actual price
6. **Results display** → Shows estimated price + input summary instantly

---

## 🛠️ Customization Options

### Change Port Number
Edit `app.py`, line 88:
```python
app.run(debug=True, host='0.0.0.0', port=5001)  # Change 5000 to 5001
```

### Add More Locations (Dropdown)
The app currently accepts any text for location. To add a predefined dropdown:
1. Modify `templates/index.html` - replace text input with `<select>`
2. The `app.py` automatically extracts available locations from your model

### Deploy to Web
See README.md for Heroku, Docker, or traditional hosting instructions.

---

## ⚠️ Common Issues & Fixes

### "Model file not found"
```
✅ Solution: Make sure house_price_model.pkl is in the same folder as app.py
```

### "Port 5000 already in use"
```
✅ Solution: Change port number in app.py (see Customization section)
```

### "ModuleNotFoundError: No module named 'flask'"
```
✅ Solution: Run: pip install -r requirements.txt
```

### Prediction seems off
```
✅ Check: Did you use log1p transformations during training? 
         The app applies the same transformations.
```

---

## 📚 Next Steps

1. ✅ Run the app locally using `run.bat` (Windows) or `run.sh` (Linux/Mac)
2. 📝 Test predictions with sample inputs
3. 🎨 Customize the UI if needed (edit `templates/index.html`)
4. 🚀 Deploy to cloud when ready (see README.md)
5. 📊 Monitor predictions and collect feedback

---

## 💡 Tips

- **Test API directly**: Use Postman or curl to test `/predict` endpoint
- **Health check**: Visit `http://localhost:5000/health` to verify server status
- **Enable CORS**: If accessing from different domain, uncomment CORS in `app.py`
- **Debug mode**: Currently enabled - auto-reloads on code changes
- **Production**: Disable debug mode and use Gunicorn for production deployment

---

## 🎯 Key Features Summary

| Feature | Frontend | Backend |
|---------|----------|---------|
| Input Validation | ✅ Client-side | ✅ Server-side |
| Error Handling | ✅ User-friendly messages | ✅ Detailed logging |
| Model Loading | - | ✅ On startup |
| Transformations | - | ✅ Log1p/expm1 |
| Predictions | ✅ Display results | ✅ Ridge Regression |
| Performance | ⚡ Fast UI | ⚡ <100ms predictions |

---

## 📞 Support

- Check **README.md** for detailed API documentation
- Review **app.py** comments for backend logic
- Inspect **templates/index.html** for frontend structure
- Enable debug logs: `app.run(debug=True)`

---

**Happy predicting! 🏠💰**
